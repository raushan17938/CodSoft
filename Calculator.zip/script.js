const display = document.getElementById('display');
const buttons = document.querySelectorAll('button');

let currentInput = '';
let currentOperator = '';
let firstOperand = '';

buttons.forEach((button) => {
    button.addEventListener('click', () => {
        const value = button.textContent;

        if (!isNaN(value) || value === '.') {
            currentInput += value;
        } else if (value === 'C') {
            clearCalculator();
        } else if (value === '+' || value === '-' || value === '*' || value === '/') {
            handleOperator(value);
        } else if (value === '=') {
            calculateResult();
        }

        updateDisplay();
    });
});

function clearCalculator() {
    currentInput = '';
    currentOperator = '';
    firstOperand = '';
}

function handleOperator(operator) {
    if (currentInput === '') return;
    if (firstOperand === '') {
        firstOperand = currentInput;
        currentInput = '';
        currentOperator = operator;
    } else {
        calculateResult();
        currentOperator = operator;
    }
}

function calculateResult() {
    if (currentInput === '' || firstOperand === '') return;
    
    switch (currentOperator) {
        case '+':
            currentInput = (parseFloat(firstOperand) + parseFloat(currentInput)).toString();
            break;
        case '-':
            currentInput = (parseFloat(firstOperand) - parseFloat(currentInput)).toString();
            break;
        case '*':
            currentInput = (parseFloat(firstOperand) * parseFloat(currentInput)).toString();
            break;
        case '/':
            if (currentInput === '0') {
                alert("Division by zero is not allowed.");
                clearCalculator();
                return;
            }
            currentInput = (parseFloat(firstOperand) / parseFloat(currentInput)).toString();
            break;
    }

    currentOperator = '';
    firstOperand = '';
}

function updateDisplay() {
    display.textContent = currentInput;
}
